# Freshcart
Ecommerce website template

FreshCart is beautiful eCommerce HTML template specially designed for the multipurpose shops like mega store, grocery store, supermarket, organic shop, and online stores selling products. You can build an impactful store website for your online shop or other similar businesses without grounding things up. Moreover, it’s clean, minimal, and beautiful design with 100% responsive layouts will hook the visitors at first sight.

### Documentation ###

Development documentation is available at `src/docs/index.html` (or `dist/docs/index.html` once you've compiled), or visit https://freshcart.codescandy.com/docs/index.html.

### Getting Started ###

The steps to compile and get started with development are covered in detail in documentation mentioned above, but the summary is:

- npm install -g gulp-cli
- npm install
- gulp


### Support ###

Codescandy is happy to provide support for issues. Contact us an email at hello@codescandy.com